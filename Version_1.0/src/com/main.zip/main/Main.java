package com.main;

import com.main.java.UI.FinanceTrackerUI;
import com.main.java.UI.LoginPage;

public class Main {
    public static void main(String[] args) {
        // 启动登录页面
        new LoginPage();
    }
}
