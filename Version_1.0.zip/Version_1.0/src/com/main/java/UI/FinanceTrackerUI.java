package com.main.java.UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FinanceTrackerUI extends JFrame {
    private String username;

    public FinanceTrackerUI(String username) {
        this.username = username;
        setTitle("BuckBrainAI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        // 最外层 BorderLayout
        setLayout(new BorderLayout());

        // 1) 左侧侧边栏
        JPanel sideBarPanel = createSideBarPanel();
        add(sideBarPanel, BorderLayout.WEST);

        // 2) 顶部导航条
        JPanel topBarPanel = createTopBarPanel();
        add(topBarPanel, BorderLayout.NORTH);

        // 3) 主体内容（嵌套布局）
        JPanel mainContentPanel = createMainContentPanel();
        add(mainContentPanel, BorderLayout.CENTER);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * ========== 左侧侧边栏 ==========
     */
    private JPanel createSideBarPanel() {
        JPanel sideBar = new JPanel();
        sideBar.setPreferredSize(new Dimension(180, 0)); 
        sideBar.setBackground(Color.white);
        sideBar.setLayout(new BoxLayout(sideBar, BoxLayout.Y_AXIS));

        // 顶部的项目名称/Logo
        JLabel logoLabel = new JLabel("BuckBrainAI");
        logoLabel.setFont(new Font("Arial", Font.BOLD, 18));
        logoLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        sideBar.add(logoLabel);

        // 一些功能菜单按钮
        sideBar.add(createSideBarButton("Dashboard"));
        sideBar.add(createSideBarButton("Transactions"));
        sideBar.add(createSideBarButton("Accounts"));
        sideBar.add(createSideBarButton("Investments"));
        sideBar.add(createSideBarButton("Credit Cards"));
        sideBar.add(createSideBarButton("Bucks Brain"));
        sideBar.add(createSideBarButton("Setting"));

        // 中间填充
        sideBar.add(Box.createVerticalGlue());

        return sideBar;
    }

    /**
     * 侧边按钮通用样式
     */
    private JButton createSideBarButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(160, 40));
        button.setFocusPainted(false);
        button.setBackground(Color.white);
        button.setForeground(Color.black);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        // 简单的鼠标悬停效果
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(230, 230, 230));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(Color.white);
            }
        });
        return button;
    }

    /**
     * ========== 顶部导航条 ==========
     */
    private JPanel createTopBarPanel() {
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setPreferredSize(new Dimension(getWidth(), 60));
        topBar.setBackground(Color.white);

        // 左侧：Overview
        JLabel overviewLabel = new JLabel("Overview");
        overviewLabel.setFont(new Font("Arial", Font.BOLD, 16));
        overviewLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        topBar.add(overviewLabel, BorderLayout.WEST);

        // 右侧：用户欢迎+头像
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        userPanel.setOpaque(false);

        JLabel userNameLabel = new JLabel("Hello, " + username + "  ");
        userNameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        userPanel.add(userNameLabel);

        // 示例头像
        JLabel userAvatar = new JLabel();
        userAvatar.setIcon(new ImageIcon(
            new ImageIcon("avatar.png").getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH)
        ));
        userPanel.add(userAvatar);

        topBar.add(userPanel, BorderLayout.EAST);

        return topBar;
    }

    /**
     * ========== 中间的主内容，嵌套布局划分三行 ==========
     */
    private JPanel createMainContentPanel() {
        // 用 BorderLayout 将主内容分为上中下三个部分
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.white);

        // --- 第 1 行：My Cards + Recent Transactions ---
        JPanel row1 = new JPanel(new BorderLayout(10, 10));
        row1.setOpaque(false);
        row1.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 左侧 “My Cards”
        JPanel cardsPanel = createCardsPanel();
        row1.add(cardsPanel, BorderLayout.CENTER);

        // 右侧 “Recent Transactions”
        JPanel recentPanel = createRecentTransactionPanel();
        row1.add(recentPanel, BorderLayout.EAST);

        mainPanel.add(row1, BorderLayout.NORTH);

        // --- 第 2 行：Weekly Activity + Weekly Expense ---
        // 可以让它在中间区域随窗口伸缩
        JPanel row2 = new JPanel(new GridLayout(1, 2, 10, 10));
        row2.setOpaque(false);
        row2.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JPanel weeklyActivityPanel = createWeeklyActivityPanel();
        JPanel weeklyExpensePanel = createWeeklyExpensePanel();

        row2.add(weeklyActivityPanel);
        row2.add(weeklyExpensePanel);

        mainPanel.add(row2, BorderLayout.CENTER);

        // --- 第 3 行：Add transactions ---
        JPanel row3 = createAddTransactionPanel();
        row3.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(row3, BorderLayout.SOUTH);

        return mainPanel;
    }

    // ========== 各小块组件 ==========

    private JPanel createCardsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 20));
        panel.setBackground(new Color(245, 245, 245));

        // 两张模拟卡
        JPanel card1 = createSingleCardPanel("Balance: $5,756", "CARD HOLDER\nEddy Cusuma", "**** **** **** 1234");
        JPanel card2 = createSingleCardPanel("Balance: $5,756", "CARD HOLDER\nEddy Cusuma", "**** **** **** 1234");

        panel.add(card1);
        panel.add(card2);
        return panel;
    }

    private JPanel createSingleCardPanel(String balance, String cardHolder, String number) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setPreferredSize(new Dimension(180, 110));
        card.setBackground(new Color(0x3D5AFE)); // 蓝色

        JLabel balanceLabel = new JLabel(balance, SwingConstants.CENTER);
        balanceLabel.setForeground(Color.white);
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        balanceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel holderLabel = new JLabel("<html>" + cardHolder.replace("\n", "<br>") + "</html>", SwingConstants.CENTER);
        holderLabel.setForeground(Color.white);
        holderLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        holderLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel numberLabel = new JLabel(number, SwingConstants.CENTER);
        numberLabel.setForeground(Color.white);
        numberLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        numberLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(Box.createVerticalStrut(10));
        card.add(balanceLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(holderLabel);
        card.add(Box.createVerticalStrut(5));
        card.add(numberLabel);
        card.add(Box.createVerticalStrut(10));
        return card;
    }

    private JPanel createRecentTransactionPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createTitledBorder("Recent Transactions"));

        panel.add(new JLabel("Deposit from my Card  | -$850"));
        panel.add(new JLabel("Deposit Paypal        | +$2,500"));
        panel.add(new JLabel("Jemi Wilson           | +$5,400"));

        return panel;
    }

    private JPanel createWeeklyActivityPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Weekly Activity"));
        JLabel placeholder = new JLabel("Bar Chart Placeholder", SwingConstants.CENTER);
        placeholder.setFont(new Font("Arial", Font.ITALIC, 16));
        panel.add(placeholder, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createWeeklyExpensePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Weekly Expense Statistics"));
        JLabel placeholder = new JLabel("Pie Chart Placeholder", SwingConstants.CENTER);
        placeholder.setFont(new Font("Arial", Font.ITALIC, 16));
        panel.add(placeholder, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createAddTransactionPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JLabel label = new JLabel("Add transactions:");
        label.setFont(new Font("Arial", Font.BOLD, 14));

        JButton manualButton = new JButton("Manually add");
        manualButton.setPreferredSize(new Dimension(120, 40));

        JButton fileButton = new JButton("Add as file");
        fileButton.setPreferredSize(new Dimension(120, 40));

        panel.add(label);
        panel.add(manualButton);
        panel.add(new JLabel("OR"));
        panel.add(fileButton);

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new FinanceTrackerUI("zzc");
        });
    }
}
